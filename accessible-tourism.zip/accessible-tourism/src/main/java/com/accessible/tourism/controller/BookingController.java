package com.accessible.tourism.controller;

import com.accessible.tourism.model.Booking;
import com.accessible.tourism.service.BookingService;
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.time.LocalDate;

@Controller
public class BookingController {

    private final BookingService bookingService = BookingService.getInstance();

    @PostMapping("/confirmBooking")
    public String confirmBooking(@RequestParam("name") String name,
                                 @RequestParam("email") String email,
                                 @RequestParam("checkin") String checkin,
                                 @RequestParam("checkout") String checkout,
                                 @RequestParam("paymentMethod") String paymentMethod,
                                 Model model) {

        Booking booking = new Booking("Sunrise Paradise Resort", name, email, LocalDate.parse(checkin));
        bookingService.saveBooking(booking);
        model.addAttribute("booking", booking);
        return "booking-confirm";
    }

    @GetMapping("/download-pdf")
    public void downloadPDF(@RequestParam String username,
                            @RequestParam String hotelName,
                            @RequestParam String date,
                            HttpServletResponse response) throws IOException {
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=booking-confirmation.pdf");

        try {
            Document document = new Document();
            PdfWriter.getInstance(document, response.getOutputStream());
            document.open();
            document.add(new Paragraph("Booking Confirmation"));
            document.add(new Paragraph("Name: " + username));
            document.add(new Paragraph("Hotel: " + hotelName));
            document.add(new Paragraph("Booking Date: " + date));
            document.add(new Paragraph("Status: Confirmed"));
            document.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
