package com.accessible.tourism.model;

public class Hotel {
    private int id;
    private String name;
    private String city;
    private String address;
    private String contact;
    private String imagePath;
    private boolean wheelchairAccessible;
    private boolean visualAidAvailable;
    private int roomsAvailable;

    public Hotel(int id, String name, String city, String address, String contact, String imagePath,
                 boolean wheelchairAccessible, boolean visualAidAvailable, int roomsAvailable) {
        this.id = id;
        this.name = name;
        this.city = city;
        this.address = address;
        this.contact = contact;
        this.imagePath = imagePath;
        this.wheelchairAccessible = wheelchairAccessible;
        this.visualAidAvailable = visualAidAvailable;
        this.roomsAvailable = roomsAvailable;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getCity() { return city; }
    public String getAddress() { return address; }
    public String getContact() { return contact; }
    public String getImagePath() { return imagePath; }
    public boolean isWheelchairAccessible() { return wheelchairAccessible; }
    public boolean isVisualAidAvailable() { return visualAidAvailable; }
    public int getRoomsAvailable() { return roomsAvailable; }

    public void setRoomsAvailable(int roomsAvailable) {
        this.roomsAvailable = roomsAvailable;
    }
}