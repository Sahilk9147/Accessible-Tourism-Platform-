package com.accessible.tourism.observer;

public interface BookingObserver {
    void notify(String message);
}
