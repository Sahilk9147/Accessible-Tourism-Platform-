package com.accessible.tourism;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccessibleTourismApplication {
    public static void main(String[] args) {
        SpringApplication.run(AccessibleTourismApplication.class, args);
    }
}
