package com.accessible.tourism.observer;

public class EmailNotifier implements BookingObserver {
    @Override
    public void notify(String message) {
        System.out.println("[Email] 📧 " + message);
    }
}
