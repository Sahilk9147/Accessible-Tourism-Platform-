package com.accessible.tourism.controller;

import com.accessible.tourism.factory.HotelFactory;
import com.accessible.tourism.model.Hotel;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.stream.Collectors;

@Controller
public class MainController {

    private List<Hotel> allHotels = HotelFactory.getAllHotels();

    @GetMapping("/")
    public String home() {
        return "home";
    }

    @GetMapping("/hotels")
    public String showAllHotels(Model model) {
        model.addAttribute("hotels", allHotels);
        return "hotels";
    }

    @GetMapping("/hotels/{city}")
    public String showHotelsByCity(@PathVariable String city, Model model) {
        List<Hotel> filteredHotels = allHotels.stream()
                .filter(h -> h.getCity().equalsIgnoreCase(city))
                .collect(Collectors.toList());
        model.addAttribute("city", city);
        model.addAttribute("hotels", filteredHotels);
        return "hotels";
    }

    @GetMapping("/services")
    public String servicesPage() {
        return "services";
    }

    @GetMapping("/contact")
    public String contactPage() {
        return "contact";
    }

    @GetMapping("/search")
    public String searchHotelsByDestination(@RequestParam("query") String query, Model model) {
      if (query == null || query.trim().isEmpty()) {
        return "redirect:/hotels";
    }

    String q = query.trim().toLowerCase();

    List<Hotel> filteredHotels = allHotels.stream()
            .filter(h -> h.getCity() != null &&
                         h.getCity().toLowerCase().contains(q))
            .collect(Collectors.toList());

    System.out.println("Search query: " + query);
    System.out.println("Matching hotels: " + filteredHotels.size());

    model.addAttribute("hotels", filteredHotels);
    model.addAttribute("city", query);
    return "destinations";
}

}
