package com.accessible.tourism.factory;

import com.accessible.tourism.model.Hotel;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class HotelFactory {

    public static List<Hotel> getAllHotels() {
        List<Hotel> hotels = new ArrayList<>();
        hotels.add(new Hotel(1, "Taj Hotel", "Mumbai", "123 Marine Drive, Mumbai", "022-12345678", "images/mumbai_taj.jpg", true, true, 3));
        hotels.add(new Hotel(2, "The Leela Palace", "Bangalore", "456 Palace Road, Bangalore", "080-23456789", "images/bangalore_leela.jpg", true, false, 2));
        hotels.add(new Hotel(3, "Oberoi Rajvilas", "Jaipur", "789 Royal Street, Jaipur", "0141-9876543", "images/jaipur_oberoi.jpg", true, true, 3));
        hotels.add(new Hotel(4, "Radisson Blu", "Delhi", "12 Airport Road, Delhi", "011-4567890", "images/delhi_radisson.jpg", true, true, 2));
        hotels.add(new Hotel(5, "Sunrise", "Goa", "34 Beach View, Goa", "0832-8765432", "images/goa_vivanta.jpg", true, false, 3));
        hotels.add(new Hotel(6, "Hyatt Regency", "Chennai", "56 Bay Area, Chennai", "044-1122334", "images/chennai_hyatt.jpg", true, true, 3));
        hotels.add(new Hotel(7, "Park Hyatt", "Hyderabad", "789 Banjara Hills, Hyderabad", "040-9988776", "images/hyderabad_parkhyatt.jpg", false, true, 2));
        hotels.add(new Hotel(8, "ITC Grand Chola", "Chennai", "1 Mount Road, Chennai", "044-4455667", "images/chennai_itc.jpg", true, true, 3));
        hotels.add(new Hotel(9, "Marriott", "Pune", "77 MG Road, Pune", "020-3334455", "images/pune_marriott.jpg", true, false, 2));
        hotels.add(new Hotel(10, "Westin", "Kolkata", "23 Park Street, Kolkata", "033-5566778", "images/kolkata_westin.jpg", true, true, 3));
        return hotels;
    }

    public static List<Hotel> getHotelsByDestination(String destination) {
        return getAllHotels().stream()
                .filter(h -> h.getCity().equalsIgnoreCase(destination))
                .collect(Collectors.toList());
    }
}
