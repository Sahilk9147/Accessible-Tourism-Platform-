package com.accessible.tourism.controller;

import com.accessible.tourism.factory.HotelFactory;
import com.accessible.tourism.model.Booking;
import com.accessible.tourism.model.Hotel;
import com.accessible.tourism.model.User;
import com.accessible.tourism.service.BookingService;
import com.accessible.tourism.util.ReceiptGenerator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@Controller
public class HotelController {

    private final BookingService bookingService = BookingService.getInstance();
    private static final boolean GENERATE_RECEIPT = false; // Toggle receipt generation

    @GetMapping("/destinations")
    public String destinationPage() {
        return "destinations";
    }

    @PostMapping("/search")
    public String showHotels(@RequestParam String destination, Model model) {
        List<Hotel> hotels = HotelFactory.getHotelsByDestination(destination);
        model.addAttribute("hotels", hotels);
        model.addAttribute("destination", destination);
        return "destinations";
    }

    @GetMapping("/hotel/{id}")
    public String viewHotel(@PathVariable int id, Model model) {
        List<Hotel> allHotels = HotelFactory.getAllHotels();
        for (Hotel h : allHotels) {
            if (h.getId() == id) {
                model.addAttribute("hotel", h);
                return "hotel-details";
            }
        }
        return "redirect:/destinations";
    }

    @GetMapping("/book/{id}")
    public String bookHotel(@PathVariable int id, Model model) {
        List<Hotel> allHotels = HotelFactory.getAllHotels();
        for (Hotel h : allHotels) {
            if (h.getId() == id) {
                model.addAttribute("hotel", h);
                return "book-form";
            }
        }
        return "redirect:/destinations";
    }

    @PostMapping("/book/confirm")
    public String confirmBooking(@RequestParam String hotelId,
                                 @RequestParam String hotelName,
                                 @RequestParam String username,
                                 @RequestParam String email,
                                 @RequestParam String date,
                                 Model model) {
        List<Hotel> allHotels = HotelFactory.getAllHotels();
        int id = Integer.parseInt(hotelId);
        Hotel bookedHotel = allHotels.stream()
                .filter(h -> h.getId() == id)
                .findFirst()
                .orElse(null);

        if (bookedHotel == null || bookedHotel.getRoomsAvailable() <= 0) {
            model.addAttribute("error", "Hotel not available.");
            return "book-form";
        }

        bookedHotel.setRoomsAvailable(bookedHotel.getRoomsAvailable() - 1);
        Booking booking = new Booking(hotelName, username, email, LocalDate.parse(date));
        bookingService.saveBooking(booking);

        String receiptPath = null;
        if (GENERATE_RECEIPT) {
            receiptPath = ReceiptGenerator.generateReceipt(new User(username, email, ""), bookedHotel);
        }

        model.addAttribute("booking", booking);
        model.addAttribute("hotel", bookedHotel);
        model.addAttribute("receiptPath", receiptPath);
        return "booking-confirm";
    }
}