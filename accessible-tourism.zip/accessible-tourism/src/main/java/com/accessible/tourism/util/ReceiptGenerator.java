package com.accessible.tourism.util;

import com.accessible.tourism.model.Hotel;
import com.accessible.tourism.model.User;

public class ReceiptGenerator {
    public static String generateReceipt(User user, Hotel hotel) {
        // Simple text-based receipt (no PDF)
        String receipt = "Booking Receipt\n" +
                "Name: " + user.getName() + "\n" +
                "Hotel: " + hotel.getName() + "\n" +
                "City: " + hotel.getCity() + "\n" +
                "Address: " + hotel.getAddress() + "\n" +
                "Status: Confirmed";
        System.out.println(receipt);
        return "receipt-" + user.getName() + ".txt"; // Placeholder file name
    }
}