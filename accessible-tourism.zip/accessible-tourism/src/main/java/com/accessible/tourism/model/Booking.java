package com.accessible.tourism.model;

import java.time.LocalDate;

public class Booking {
    private int id;
    private String hotelName;
    private String username; // used for 'name'
    private String email;
    private LocalDate bookingDate;

    public Booking() {}

    public Booking(String hotelName, String username, String email, LocalDate bookingDate) {
        this.hotelName = hotelName;
        this.username = username;
        this.email = email;
        this.bookingDate = bookingDate;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getHotelName() { return hotelName; }
    public void setHotelName(String hotelName) { this.hotelName = hotelName; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public LocalDate getBookingDate() { return bookingDate; }
    public void setBookingDate(LocalDate bookingDate) { this.bookingDate = bookingDate; }
}
