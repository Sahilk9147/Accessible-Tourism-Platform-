package com.accessible.tourism.observer;

public class SMSNotifier implements BookingObserver {
    @Override
    public void notify(String message) {
        System.out.println("[SMS] 📲 " + message);
    }
}
