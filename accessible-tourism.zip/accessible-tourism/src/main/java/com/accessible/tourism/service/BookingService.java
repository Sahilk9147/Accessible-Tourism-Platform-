package com.accessible.tourism.service;

import com.accessible.tourism.model.Booking;
import java.util.ArrayList;
import java.util.List;

public class BookingService {
    private static BookingService instance;
    private List<Booking> bookings = new ArrayList<>();
    private int nextId = 1;

    private BookingService() {}

    public static BookingService getInstance() {
        if (instance == null) {
            instance = new BookingService();
        }
        return instance;
    }

    public void saveBooking(Booking booking) {
        booking.setId(nextId++);
        bookings.add(booking);
        // Simple notification (replacing observer pattern)
        System.out.println("Booking confirmed for " + booking.getUsername() +
                " at " + booking.getHotelName() + " on " + booking.getBookingDate());
    }

    public List<Booking> getAllBookings() {
        return new ArrayList<>(bookings);
    }
}