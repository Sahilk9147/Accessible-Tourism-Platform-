package com.accessible.tourism.controller;

import com.accessible.tourism.model.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

@Controller
public class AuthController {

    private static final List<User> users = new ArrayList<>();

    @GetMapping("/signup")
    public String signupPage() {
        return "signup";
    }

    @PostMapping("/signup")
    public String signup(@RequestParam String name,
                        @RequestParam String email,
                        @RequestParam String phone,
                        @RequestParam String password,
                        Model model) {
        if (users.stream().anyMatch(u -> u.getEmail().equals(email))) {
            model.addAttribute("error", "Email already registered.");
            return "signup";
        }
        users.add(new User(name, email, phone));
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String email,
                       @RequestParam String password,
                       Model model) {
        if (users.stream().anyMatch(u -> u.getEmail().equals(email))) {
            return "redirect:/";
        }
        model.addAttribute("error", "Invalid email or password.");
        return "login";
    }

    @PostMapping("/logout")
    public String logout() {
        // Placeholder: Clear session or state if needed
        return "redirect:/";
    }
}