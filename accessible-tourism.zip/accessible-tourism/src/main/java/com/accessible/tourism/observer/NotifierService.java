package com.accessible.tourism.observer;

import java.util.ArrayList;
import java.util.List;

public class NotifierService {
    private static NotifierService instance;
    private final List<BookingObserver> observers = new ArrayList<>();

    private NotifierService() {}

    public static NotifierService getInstance() {
        if (instance == null) {
            instance = new NotifierService();
        }
        return instance;
    }

    public void addObserver(BookingObserver observer) {
        observers.add(observer);
    }

    public void notifyAllObservers(String msg) {
        for (BookingObserver o : observers) {
            o.notify(msg);
        }
    }
}
